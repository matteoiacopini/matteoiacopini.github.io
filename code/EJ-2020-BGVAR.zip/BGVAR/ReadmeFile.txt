%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This archive contains data and codes for replicating the analysis in
% Casarin, R., Iacopini, M., Molina, G. Ter Horst, E., Espinasa, R., Sucre, C., and Rigobon, R. (2019).
% Multilayer Network Analysis of Oil Linkages
% Econometrics Journal, 2019.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Main codes description:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
OilNetworkRep.m
This code allows for the extraction of the contemporaneous and lagged multi-layer
networks in Section 3 of the paper. The pictures of the networks presented in 
this paper have been generated with Gephi, available at: https://gephi.org/

OilNetworkSequential.m
This code allows for the sequential extraction of the contemporaneous and lagged multi-layer
networks in Section 4 of the paper. Figures of Section 4 can be generated with this code.

OilNetworkSequentialParallelRep.m
This code is a parallel implementation of the sequential estimation code OilNetworkSequential.m


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Subfolders description:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data
This folder contains the dataset used (AllData.mat) and the labels of the series (ListVar.mat).

functions
This folder contains all functions used by OilNetworkSequential.m and OilNetwork.m
adj2edgeL.m                converts an adjacency matrix into an edge list
CONVERGENCE.m              implements convergence diagnostics and statistics
Estimate_BIC.m             evaluates the BIC
Gibbs.m                    runs the Gibbs (used only by OilNetworkSequentialParallelRep.m)
LOG_SCORE.m                evaluates the log-score of the nework
PROC_DATA.m                applies data transformation
SAMPLE_BGMAR_DAG.m         samplse the lagged DAG          (global sampler)
SAMPLE_BGMIN_DAG.m         samples the contemporeanous DAG (global sampler)
SAMPLE_BGMAR_DAGblocks.m   samples the lagged DAG          (blocked sampler, Section 2 of the paper)
SAMPLE_BGMIN_DAGblocks.m   samples the contemporeanous DAG (blocked sampler, Section 2 of the paper)
smth.m                     smooths a time series (used by OilNetworkSequentialRep.m)
transform.m                transforms raw time into stationary series

results
This folder contains some results obtained with the codes described in this document, including
the .mat files with the MCMC output and the .csv files to be used as inputs by Gephi.
