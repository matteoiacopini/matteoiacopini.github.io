
# Bayesian SAR Model with Stochastic Volatility and Multiple Time-Varying Weights

This README provides instructions on how to run the proposed model using an example dataset. The model is presented in:

> **Costola, M., Iacopini, M., & Wichers, C. (2024).** *Bayesian SAR model with stochastic volatility and multiple time-varying weights*. *Journal of Financial Econometrics*.

**Note**: The data used in the published paper are proprietary and cannot be shared. A synthetic dataset is provided instead for estimation purposes.

---

## File Descriptions

### 1. `ExampleData.RData`
- A synthetic dataset used to illustrate the estimation procedure.

### 2. `main_example.R`
- Main script to estimate the model using the function `gibbs_sv`.
- Spillover Effects: The script also computes the spillover effects. 
---

## How to Run the Code

Open and execute `main_example.R`. In line 57, the function `gibbs_sv` is called with the following inputs:

| Argument         | Description                                                                 |
|------------------|-----------------------------------------------------------------------------|
| `nsave`          | Number of saved iterations (default: 2000)                                |
| `nburn`          | Number of burn-in iterations (default: 1500)                                |
| `nshow`          | Iteration counter display interval (default: 100)                           |
| `ft`             | Matrix of common factors *fₜ* (explanatory variables)                       |
| `y`              | Dependent variable                                                          |
| `min_network`    | Time-varying spatial weights (layer 1 of the network)                       |
| `plus_network`   | Time-varying spatial weights (layer 2 of the network)                       |
| `nu`, `rho_params`, `prior_rho` | Hyperparameters                                             |
| `fixed.effects`  | TRUE/FALSE to activate/deactivate individual fixed effects                 |

The corresponding synthetic variables are:

```r
ft           <- data_sarsv$ft           # explanatory variables
y            <- data_sarsv$yt           # dependent variable
min_network  <- data_sarsv$net1_norm    # spatial weight matrix 1
plus_network <- data_sarsv$net2_norm    # spatial weight matrix 2
```

To use your own data, please conform to this structure.

---

## Outputs and Interpretation

The function `gibbs_sv.R` outputs a list called `results`, which contains all quantities required for Bayesian inference. Post-estimation analyses such as plotting, posterior means, and credible intervals must be computed from the stored outputs.

### Key output objects (see `gibbs_sv.R`, line 210):

| Variable        | Description & Use                                                       |
|------------------|-------------------------------------------------------------------------|
| `beta.store`     | Posterior draws of coefficients β                                        |
| `delta.store`    | Posterior draws of δ₁ and δ₂                                              |
| `rho.store`      | City/country-level ρⱼ draws                                                  |
| `ht.store`       | Draws of time-varying volatilities                                   |


## Auxiliary Scripts

| File                       | Purpose                                                                 |
|----------------------------|-------------------------------------------------------------------------|
| `gibbs_sv.R`               | Gibbs sampler for the full model                                        |
| `log_target_dens_delta_sv.R` | Defines the target density for δ                                      |
| `max_row_norm.R`           | Computes max row norm of a matrix                                       |
| `metropolis_delta_sv.R`    | Metropolis-Hastings algorithm for δ                                     |
| `norm_rows.R`              | Row normalization utilities                                             |
| `sample_eta.R`             | Samples the latent parameter η                                          |
| `sample_rho_sv.R`          | Samples the spatial weight ρ                                            |
| `spginv.R`                 | Computes generalized matrix inverse                                     |
| `uni.slice.R`              | Univariate slice sampling implementation                                |

---

## Usage Policy

This code is provided as a research tool. Users are expected to adapt the model and post-processing scripts to their own datasets and use cases. 